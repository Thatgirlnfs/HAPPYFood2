import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'info_recette_model.dart';
export 'info_recette_model.dart';

class InfoRecetteWidget extends StatefulWidget {
  const InfoRecetteWidget({Key? key}) : super(key: key);

  @override
  _InfoRecetteWidgetState createState() => _InfoRecetteWidgetState();
}

class _InfoRecetteWidgetState extends State<InfoRecetteWidget>
    with TickerProviderStateMixin {
  late InfoRecetteModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = {
    'imageOnPageLoadAnimation': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 600.ms),
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 600.ms,
          duration: 600.ms,
          begin: 0.0,
          end: 1.0,
        ),
      ],
    ),
    'rowOnPageLoadAnimation1': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1000.ms),
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 1000.ms,
          duration: 600.ms,
          begin: 0.0,
          end: 1.0,
        ),
      ],
    ),
    'rowOnPageLoadAnimation2': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1200.ms),
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 1200.ms,
          duration: 600.ms,
          begin: 0.0,
          end: 1.0,
        ),
      ],
    ),
    'containerOnPageLoadAnimation1': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1400.ms),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 1400.ms,
          duration: 600.ms,
          begin: Offset(0.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'rowOnPageLoadAnimation3': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1400.ms),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 1400.ms,
          duration: 600.ms,
          begin: Offset(0.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'containerOnPageLoadAnimation2': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1400.ms),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 1400.ms,
          duration: 600.ms,
          begin: Offset(0.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'containerOnPageLoadAnimation3': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1400.ms),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 1400.ms,
          duration: 600.ms,
          begin: Offset(0.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'columnOnPageLoadAnimation1': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 1400.ms,
          duration: 600.ms,
          begin: Offset(-20.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'columnOnPageLoadAnimation2': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1400.ms),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 1400.ms,
          duration: 600.ms,
          begin: Offset(0.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'columnOnPageLoadAnimation3': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        VisibilityEffect(duration: 1800.ms),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 1800.ms,
          duration: 600.ms,
          begin: Offset(-20.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
  };

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InfoRecetteModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isiOS) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarBrightness: Theme.of(context).brightness,
          systemStatusBarContrastEnforced: true,
        ),
      );
    }

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Stack(
          children: [
            InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onLongPress: () async {
                context.safePop();
              },
              child: Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        width: 425.0,
                        height: 254.0,
                        decoration: BoxDecoration(
                          color: Color(0x27000000),
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 9.0,
                              color: Color(0x33000000),
                              offset: Offset(0.0, 2.0),
                              spreadRadius: 8.0,
                            )
                          ],
                          borderRadius: BorderRadius.circular(24.0),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(24.0),
                                  child: Image.network(
                                    'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFhUYGBgYHBgeHBwaGhgaGBoZGBgaGhoZGBocIS4lHB4rIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISHzQrJCs0NDQ0NDE0NDQxNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAK8BHwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAADBAIFAAEGBwj/xAA/EAACAQIEAwUFBgUDAwUAAAABAhEAAwQSITEFQVEiYXGBkQYTMqGxQlLB0eHwFBVicoIjkvEHFqIkM0RTwv/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACURAAICAgICAgIDAQAAAAAAAAABAhEhMQMSQVETIjJhBIHwFP/aAAwDAQACEQMRAD8A9kqJqZqBpMDBW4qGat5qVgbqJNRZ6iDrR2HQasrQrdMRGsqVRNAGVlZWUAZWq3WqAMrK3WUAarRFSrVAGiKyKwmovPKpckhpWSiose6akum9QbEAEDr6VMpL2NI0LvVTWjdB01HjUbl4c6XbEjpWbm15L6pksVbIE7iqjEknaruw4IidOhoAsgMRFH5C0IYKyw1ireyOtTtIKNlrWMaJbsh7sVFkFFNQNWIQvPBoljWi3bU0h7woazeBofa2KXutFaF8ms93NOwoEL1SL0K+kUpexWWpsKOqNQNSNRNaMki1RqRrRpMZCsFYTQneKVgNA1k0l/E1JcRVWIbmsmlxdoT4wTC6mplyRjtlRi5aHayq69jSveelaTE3G+zA61l/0x0i/ieyxJrM4pD3LHdqkcOOppfPL0Hxr2NtcHWoteETNJGx4miog2Aqfmk8UPpEIMVJgAmpX7wVcxMR018qkQAIFKM3UU5TklT2JRTZO3ezjYjx0PjRCQOZnxoL6KSOVV16+zqBGQHefiNZSn1Wcs0Ue2sItffzsaBcuAGZOsz08qRshuWZuUkQIootNzpxlKSyhNJPBJ7nPXvo1oSKHkUKTuf3pUbd3ZipQncUXUqYqtWFdMpmaYs3Q4g78qCw0k6DvpR+yZFV26sKstEcDQ0dWmuY41xBlyMmzAhtOfLz3qGA4odGnxFJfyesurQ/huNo6siomgWsWrLINDN0k10/JFq0ZdGgztVXiW1qxkxSV91mDpQ3aEkK2cRBirBLkiq0Ydc004LgFJMbMu2y1BOBU8qMlwtttR5CijDFotag1TqJrVkgmehM9Gcihll61DQwbNS7032a2LQNLqFlW6mtohqzNioska02qVgslfdJ+Hbqa2BlAgb1HEqWIO25NM4eCFPdpXmtuc3Z1YjFUEt4cbkSaKViiDahsa6eqisGXZtkWagNcI3qRt/vlQnt7kk9w/GspORcUiaXtKcQQJNV2HjMoP7gTTTX5MVfFLFsU1mkSuNQWQZSZiNzUxqQOVL3mnUbDYcvPqaqUhJC38QwBlQE6H4j39wqVhA3abxA/OipYDCW1NSYQIAqYway8jbvRMXNYFQck9PGRQw0Vt2MSFnX5czrVN4tiSB86Mu+1Dsqp7SEST2iCNT5c6YIiks5GyF1yVOmY9OX40FbfZ+Eg8wfzrU3A0llI2iI86aVqFl2DxgocdazKyHxB6Ea/hXPYe6zMqossxAAFdTjkOaSZ9PpXHcBxwTEsGOgLqDyBmATXLNfbJvD8XR0OP4gLDhCJIALEbSeQpjBcVz/AA7CqnjluXlhuo5/Md1Vdm6UaUPrUu/A41WTv7WMnn5UvxW3nTOu4rm8HxMlgSaulxYIkag6EVtxczX1kZz4/KKqxxQjQ71c4K276nQUPA8CXOXbWdulXLkKIFdUYvbMJP0ZogpZ7k1G400F2qmyUi1x3GEt7nXpVc/HRGY6CuL41hr6NmeYPMUvhcQzsqFtDWcuaV0dEeGNWdHj+P8A3CT4VQXeP3WOjEUTGcPaw+aQysPMUiMMrkkvHhUuUvJahHwdFg3vOmdbhnpSye192y0OAw9DVLZ4+LAKLJrnMdjWuOXYwOlCk1pjcE9o9n4J7WWMQQs5XP2Tz8OtXGNMZSOv1rxP2Y4PexN1HUFLasCX2mDML1r2xnGWP3pWzk3B2c8oxUvqUl66SZOw0I/KnuHzBDD4dteR1qrx9/3bZ90YwdNp5+v1pvC3gBBaQZgj8fCvNhKp2zolG44LlmHKhsaElz1qZM12drRz9aNeHOoXjWwe18z6UK+4ms5P6lRWRa52SCN5kfr3VUcV4t7ls2Vip6a/KrHEPz5UDGqrICR++6uWTd4OiKXkhw32ks3Do4kqYU6Nm6QaHwTiSuCpcT0O8zrXJ8X4ArnMunhprIkjoaSsWcQjh1JbKZkyO1I3PfFWpttO9D6Rpr2eq4d9IPKiSDrXE4L2uyaXUZB1AJHy/SujwnGrTwVdTPKYPmK6o80Xs5pcckWHu9azJWlxCkEkwBp3zWe8EwAYiZnmeVV2iRTMVFBOkH5Gg3ZJmYjlPLvG1SxeIVBJBO0xGk1J0kSKWNDzsVKEEtO51GpA7wOQpq1ETNKWpzEMpHQyCD6UxnUHKCJG45+lSqQ3YpjjrBHnyNedXEyXnB3zt9ZFel4uD6bx37VwHtThSLoYbOBPiun5VjyLBtxPJc4hS1m08TEppv8AeHymq64gbp9KsrY/9GGJ2YHw0ifnSItEdr8qyXgp4EMQApENv5U5gsbELr3zS+JdGPaBWNDpz6VUPiMrnKZinVjTPTuFcRzLk5jbvFNtXF8GvMblsTDEj0O/yrtHFdvDJyjT8HNyR6yF7ppO+9N3AaSvWWPKtDM6TH4BXUgiuF4h7GXQ5a2yx0OlejMKE1ay44y2KPJKOjznHcBxToFgEj+qqoeyOMPJR/lXq5rVQ+GJp88jzDD/APT263x3Av8AaJ+tXvD/AGFw1shnBdh97UT4bV2JNBejolol8knsTkIMqAAd1WFmMuu9KtZA1NYl7XLE0pNRWQinJ4FuI2FdWTWGBPp0/fKqHA3yjMh+IDYnQx38jpv+VdNil0zA1UY3DC5EQr6EGN+6fwrzOVVI7uKX1phsFjZMqdJ7Stus89NvEaGnbPEAzZcrKw112bwO3lVVZw2eNMl1ecaMOYPUGiriYBV0KEHQySvWc32daFKUV+hShFsug+k/Wg4q4sgDtSJFLW73JjM/aHPxqLIR+9qp8lxpGfSmKY5C3WNNufKkb+IaMpEAaCrVmOUEaTt61WcQUZyZ0gfv61nJVlFxd4YBBIMzG1WVvAZhqunL0GwpbD7/AD9NIq6wLyumwP15/WnCKbyEpNaK1eFI2kbfv86Bf9mrY1AgzoRoR4R510lq3prBoWJbpyrRwpZIU3eDisdfxNg9lg6T8Lb+TbzHMzTmG9r7TQrEo+mjlQJnYGdf1pzFW1ffrXM8a4EjA8j61MZNF0pHZ2eJIxg8x68/wpxsWNq8ht4bE4eCpOQHQEZl/TyNXWA9rAAFuhlP3viHfsNK1U2tZIlxI9Ft4lTMGY37j0qbkGTAJjTr3Ca5/h2LtOJtupBksQQZJ1q3TEjQefpVqdrJm408BsuZdBB6flVPxXh/vFKCJ10O4I2Iq0TFKSN9j6CgYh5zNoIDa9CQYpWpRyCtM5TAYmcMyMJIeI8CPyoWIdlUEbdOnpypKwSiQCdTPrTTOMoMFZ6wT+lc6N2hPF3SFnMIPLmZ7tTUcBwssczbchz8TSKW/eXwToq/hT/E8YUXsPk1A0+I90+VU/SBIJibgS8iKYYEEkHbWADXpyW9BO8CvH+D4ZmfOxkllHfrtvXsSaADoK6/462Yc/gi1sVr3QomatFq6jnLUihMtErTVoSLsKgxqdwGkbzuNhUtgHLcqx2CjvqGGBVS7bnYd1AZpM1MnRcVZhJO9ajteA06f80RRSvE8wQMu4Pl51zczqNm/Gs0bw5zZl6EHyPX0+dBWyYM9rfyEzQMbYZWUq+UkA9xrYxhYn3Z7YIkMNO1E/SuLDxLaOjr5joAVbNOroZlTG3VTyM/WOkb/iYUqsEAaq2jAdD08TI76tLOXLkMBtWIE8+hPfAqoxeGk5kOYpvyYEmIB/A0pQcVh2OMk3kVu2nQq6HsNMrsFYciOWp3FSv8SYZXGo2Pj91o33pLGh7k5HKONTtm3GgHMHXSkTichIcBZ3I0R+4/cbfu8Nqyq9GjXs6nOroroSQdY6HmD4GqvEIxOoJqs4fxBrTsuUsjGSo+JejAc9PWulsHMA6tmU/vUHY91aNWZV1FsMp1kHTny2q24Zb01HOe7uHhQrYDQIim8PbCnTWfGqgqdkyeCxJERVXjE0n/AJp+40Cq7ELyB9BW3K7MoIpbrsDG5M0Ipm8fHpVhdwrsdFPymo2sC6tPZHiwn5VzNM3TJPhgyywE/I+MVU43gVphmgAx0MTGvjXRXMLmGrgHuk1XYq06DWGHUd/dVO1miU78nEcQ4abbZ7LFSOayPpRMF7T30IF5S4+8NG9Nj8q6cor9krApHEcIU6AT0gT/AMUKXsvHkt+G8St3FBRgdNp1HcRuKJeufF/a30rnl9lnBBUhd9dRHnyolkFJUX2usAQVQBlH9znRfM0+zqkS4K7sq8ReOdUQFisAnWB4mmDeVwQVLx8TAlUU9A8gfOqvH49EJQEOdZS2ZBO/+pc594WfGkrl67eABBKgCEQHIvTQb1Si1sqrLROIYZSVyEHqrZxr3xB+dV2MvG64bZAdB3gASQKGmCIEurSZ0ggCOpPltTUFVzHswN/snfu7qeE8DobwDtavI+QSCmmvPTN416ZYxQYSDXkr8QLOrnlBJ8BAArreCcUnKQey1dPA9o5udaZ2XvKkGqvF+iLiBXTZzUdJWVlZWhJEioFJotaWgBDHNrFLKKPih2jQwKyls0WiSCh4i72shGkTRk5npUGYHQ6tEx1rn5n4RrD2J4uwSAPu6jrHMCqsXGt3A1tVZX3YnQDoRGhGms0/cvnQ5eyZB17Smdp6b0C3ikZcoWCDABEFuZ7ideR1rkq32R0rCp6J4nEAAMxgHdhrlI/DTnNAXHBCSUBLR21AhhyzRUMXh7mUrBjQwDpoR08OVQu21YMC3dHTvzeP0pdmUoqit4xeTVi6o5BglWKSSYJywQR1mqm9ccKrOPeoRIaMjkH7wO/nrVnj+HI6MobKwOY5uzJMCM20GqTDO6tDu2UE6yXiI7MH7P0pNJopG7ly24AsyYElGkR1yMNUM+XdUcPiryEMl50/puap/u2I9DQ72FVwz2mKup1iVYTt4il04m6EJdGYcyNyPAa+lCvwGGdLa9oLiwblr/JDoe8f81cYb2ssRqcp6EGR8q4hEV2myzanXKSI/uI09aletBDFx7UnoQD55dJpptCcEzrcX7b2V2V3PQAxr3mBSXGPbU27fvAg1ICqDqWOvxHoATtXO27Fh5yXYZdIJIB/tJXUUnxOx7xVQMsISdTrtHSBVKVtWT0S0XHD/bS5iA6rmtuqFh8LKYMdAedVlj2ruT/r20f+pQUf1B1qvwvDLtlluKAQZETup3B5inXRGkhCI3EgfOKclG8LA1HBeWOOs65rLtpujasvjO4oie0OJA7VsOOcAqf1rlUyCYIB1+0Z+VV1zFqTqG8tJ86ShnA3Xk9Cs8VVz2ka11zCeXKN6cv+0uHtiFJJ6R8yo19a8vGJ00tHzZoqb4m+AIS3B1EBSfPWR50/iyTg6ziXtY76Kmbpn1Qf4Lof8qrUTE4lsrucg3CwiKPLQ+GtI4MMwLXnKW1GoUkZzyUAAme+Npq2xEsurolsRCqSqRHOYJO29P8AEGkTsYXC4fRj7x+gkifAfnRb3FzlPu7SJ3uSIjmQNvWkLWLQ6IjED7UBRpzk6mothWclmaV5KPhHj+dDfsVexVeIuXIclx9ptND/AEHoNNDTCtmUMfh5TuZ5D9aZ/hUtiWVTI0XcHypVMzdpiAAT4DuFDd6KJJYZoAEkn4eSjc67Vd2QEAC6AbVXYFXBBiNN9tOlPFq34Fhs5+Z5o7Dh9wOgJ5U2sdKqOBGbbU6tyupHK9nX1Ko1laEkqwVGpUAJYxNaBFWF9JFJlaiSKiyJBjSkOIoSVuKSCvT6HuO1WS0EuAcp2aT6b1yc0b/3k3g6EUObUbH4l6HqKFi8KrJGaIGhjboGHSjvbKksDuemndQcRjVRS7gjLGoBJ9AK5ljezo3oSxWNdFClSNtWBKtp9hlkyfunWoXVRgIJXrIhu/MOdWNy4rqGnMpIlSI9QdRVLjMKrnsMZPwgnXrp13PrSkkyouhB1ZASoZkPI6jTmJoNjI5ysFQRqeZbqQaZPGLtqFdEcddu7fXXyqvucSw9wHOjIZ2I+hWoSovZK5gVBItXJJGuuWdfpSWF4W/vWa4pCBTq0ZCdBAg7xMeFJ4rh4bMbV4+AJMcxM7VVnD4lmyI7uT9lSeXOtYpPyJ2XXEcJYhnJCIAJ17QY6DSfzqpv8JLKHVg6EZpnTKDzO0betbueyl9hLvbVv67gzefSrLDcHv2rJtKyFZJzB1O8bTpy6c6rEVhk5ZUIAQSyxHSI8d+lCVlLwt4Drqf2adv8JusSHB1AEqRBAmJAqrPBNSXJQAxroT6049X5G2y7sqqaPdLZuYMhR60BsZaSWWSRt1nzNVf8vtj7YJ/u0HnFOfyhWAh1PWCNB4TR1j7C5GXOLrcKgoAO8iR6TTjY9GXLoFA0hBPmY1qtw2EtwczbTpIHzpixYsgznUeevr50mo+BKzaXU3AnTQxp6UO7jCSAFU92XSCeoqwZMNGYHUfZAJHnpQc6yMiGAeYC+ms9KWB2GDswAy5NN9/SRpUv5YSwZyWO4LGYqN6079By3ltaIuHYAS5qdDNX7wTQdqd+7TvrFe42gUII1LAgCe7rWJaQQxKnLPxE6+VY+Oc/BGmvwiB6zJpisGuE72ck6tlMHzPKnhZBMMBpsB+NI23uvILsQPAL6CmbLqshTmI3I1A6+FJpibG7Dys+PyrIrQYRpTeAsF2AFdsFSSOSe7Oh4Nby2STzohNGxLBEVBSBxFbpGL2d5NZWVlWSZWwa1WUATBoF61zFFFSmlsBGg4iwGHfr8xBFPXLXMUECspQUlTNIyp2ipw7NaUqRInsz16frSuKxloEC5KM0f1LP9wHlrVxicPm1G9UuKw6IDOZOv2l0/pOn0NcM+OUcbR1QlF5ewjgFcyEAbSIZWB56HT6UjdlBORzrMjWI0kHkKpr2AfNmw18I517EjMp3OQkq3lQL3EbiSt63Mae8tEq++5XNqfMVlg2SC4+6lyCYZpiVkONR+mtKW8GxlgFcqwgMArAgAzAG8R0pW6zXDNp0xAGuS4sXQPEZXPiC1QuXk5rfsbEz/qICNDE9oenlV9QuhbH4cq8lCvMEdkdNekTSw7SnO7KCIYqXCmD9qNDRGvXG1W+jcoZl1/3DTzisW5iUGttXWZOUqw8YWY8YpqLDsinPC7ckQpHIjn4jlWk4GrfDEjoaefjCMe2g9AQOvfU8PxGx2gwUqdgYXL3ggT86rtP9hUStTh7q0LcM9zbUZrmKUR73MOjdofOmUNvN8JK8ofX186PaCiCoceYJ0HeZo7vyKkIrjmIy3La9zJA8dNYOnWmLeMQH/wBhmHcQfwpi+HbRUaD3a+ooF/ht5wANIP4d1K4veAygqYvD6zbZP7gvnzo64nCSAHPjlbT/ACAiaBh+DPzUnTeO7vp2zwkLqyjQd2n7mk+oZBZsPBh5PIg6n9a3723lMK/LUAjYzueutQt4lAT2V0npyPXXStXMUC47She8+YPhRQDP8c76W7ajYS2w8hz861cwR+27MTuFIUef6mk8ZjypCK2h3yggf79/lS73HkQ5y9PHvNKmBY5LSGMqg76mdutJYjiO+RYXrIHoK0+FZoIQ6/a5Rtz3qwtcOUEaZhzZuv8ASuwpxiTKSRTW7Vx9Bmyk7n8Dzq5wmEKrBMCNhHzNOMB6CiWMK9w5UFbxh7MpT9AkQucqjeuu4dg1w9su+8fsCt8O4YlhM7kSNyfwqj41xcuYGijYfie+uiMayzmlK9E8ZxPMSTzqt/mJJga1U38STUMFdhwT3/SnYj3isrU1lakmVsVqsoAkKyog1uaAMJrRg9xrKi1AyDIRQb9hXEEUYkio5xzqXFMadHKcR9mmBz2HyN0gMp8VOnnvVVbuXFcLibYCyZdQziCOUyya95HlNegRQr2HVt1mueXBFmseZrZxeM4PaZsyhW00IGmsxpsdRXPYrAXVdgjvqdVMOg8nkAeFeg3uCASbblD3GPUVRYzAYxJKOjf3ID65Yrllwzjo6Y80Wche4S853tWSd+yzoT12JB9KQxGDKmQjg7yuRojvEH5VdcQuYwEZ7VtwOQWPWd/Wqw8Uj48IB1yhhPmpNCjMvtErWu6w7oe64jA/7zrPnUCj/YXDtvsEb5yfnNWa8XwzaPhm5xDt/wDqIrfuMA/aNl120zzr5EzWixsltMrFsufisCeoRSNe4ZakGYCRAPL/AE2HrqQfnTGJwmDmbdx0PRgxHky6j0rZsW1/+Zof6mM9NOdJsMEXxVxh8ZERIVIj11686VDXSCQzd0sQacy2lknEO3ULm+cxWrdyw+gViBzcR9Jqf6C0J21vf/YunMs34Gi2cM5HaxA/83H/AJaU/aKjU5QdAMiyQNdy2o5UK5bRrggyPtgq7N6cuUVSb9CtexDEDQr78tyjKdfKfrWWMLr8DnvCgD510lmzaU9hTl71g+UgfsULE2QzhwWQadnvHPQ7/lQrYdkhEWIBJBEAEgmT6AfjTaYMFZUwdNtTG5iTpO3rTeQT94nmddacw/DrriFQx1Ogpx429kS5EKWlIWGPiftHxNaWWOVBPhXSYT2YOhuN5Crm1h7NkQAAfnW8eKjGXJZz3DvZ92gvoOnOugVbdhYA16DfzqF/GMdF7I+f6Um6/s1oklozcmxHimKZ9SdOQ5CuXx7610uKt6aVQ46xzigRStNBYxqKPe0pe4KQz6Dmtg1Caya2ICTWTQwa3NABJrKgDWwaAN1o1qaw1IEGoTCjGhsKTGALkVoYipOtAdaLYDK4it+8FVrrQmdhz/Gi/Y6LN7aNvB8RSd7g9pt0WlP4xhyB+VYeJxup8jSfV7HckAxHsnZb7A+VVWI9gbLbLHhp9KvBxVejD0/OtDjNuYJI8jS6RDvI5d/+nlvr61H/ALDQbfSutHFU+98m/KsPEk+98m/Kl0Qd2cf/ANoZdkHpRF9nXAgIPSuqbidv73yb8qG3FrXUnyNHRD7s51eAXOkelGT2dfmQKuW4wnJWPoPxqH84J+FPU0dYh2kJW/Zud29KdtezNsasZ/fdUTxG4doHgPzqDO7fEzHz09KKivAu0iyTC4e3yWfKa2/EF2RfwqtS1R1WnfoTCPfdtzHhQsnWpM1QZ4oA0xoLtWM9BZp1B+VMAGIeNI9KRxCAinsQ+lKF5mgDn8bhY1iqu5brq3tAiq+7ggdaQz//2Q==',
                                    width: 413.0,
                                    height: 237.0,
                                    fit: BoxFit.cover,
                                  ),
                                ).animateOnPageLoad(
                                    animationsMap['imageOnPageLoadAnimation']!),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            20.0, 15.0, 0.0, 23.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Align(
                              alignment: AlignmentDirectional(-1.0, 0.0),
                              child: Text(
                                'Crêpes',
                                textAlign: TextAlign.start,
                                style: FlutterFlowTheme.of(context).titleMedium,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 20.0, 0.0),
                              child: Icon(
                                Icons.favorite_border_outlined,
                                color: Color(0xFF588A2B),
                                size: 24.0,
                              ),
                            ),
                          ],
                        ).animateOnPageLoad(
                            animationsMap['rowOnPageLoadAnimation1']!),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Align(
                            alignment: AlignmentDirectional(-1.0, 1.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  3.0, 0.0, 0.0, 9.0),
                              child: Container(
                                width: 131.0,
                                height: 33.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFF588A2B),
                                  borderRadius: BorderRadius.circular(14.0),
                                ),
                                child: Align(
                                  alignment: AlignmentDirectional(1.0, 0.0),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Opacity(
                                        opacity: 0.8,
                                        child: Text(
                                          'RecipeTime',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Poppins',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryBtnText,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ),
                                      Opacity(
                                        opacity: 0.8,
                                        child: Align(
                                          alignment:
                                              AlignmentDirectional(1.0, 0.0),
                                          child: Icon(
                                            Icons.access_time_rounded,
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBtnText,
                                            size: 24.0,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ).animateOnPageLoad(animationsMap[
                                      'rowOnPageLoadAnimation3']!),
                                ),
                              ).animateOnPageLoad(animationsMap[
                                  'containerOnPageLoadAnimation1']!),
                            ),
                          ),
                          Align(
                            alignment: AlignmentDirectional(-1.0, 1.0),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  3.0, 0.0, 0.0, 9.0),
                              child: Container(
                                width: 97.0,
                                height: 33.0,
                                decoration: BoxDecoration(
                                  color: Color(0xFF588A2B),
                                  borderRadius: BorderRadius.circular(14.0),
                                ),
                                child: Opacity(
                                  opacity: 0.8,
                                  child: Align(
                                    alignment: AlignmentDirectional(1.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          'Easy',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Poppins',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryBtnText,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ).animateOnPageLoad(animationsMap[
                                  'containerOnPageLoadAnimation2']!),
                            ),
                          ),
                        ],
                      ).animateOnPageLoad(
                          animationsMap['rowOnPageLoadAnimation2']!),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
                        child: Container(
                          width: 353.0,
                          height: 264.0,
                          decoration: BoxDecoration(),
                          child: Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 10.0, 0.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Align(
                                  alignment: AlignmentDirectional(-0.9, 0.0),
                                  child: Text(
                                    'Ingredients :',
                                    textAlign: TextAlign.start,
                                    style:
                                        FlutterFlowTheme.of(context).bodyMedium,
                                  ),
                                ),
                                Opacity(
                                  opacity: 0.4,
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 20.0, 0.0, 0.0),
                                    child: Container(
                                      width: 353.0,
                                      height: 184.0,
                                      decoration: BoxDecoration(
                                        color: Color(0xFF588A2B),
                                        boxShadow: [
                                          BoxShadow(
                                            blurRadius: 9.0,
                                            color: Color(0x33000000),
                                            offset: Offset(0.0, 2.0),
                                            spreadRadius: 8.0,
                                          )
                                        ],
                                        borderRadius:
                                            BorderRadius.circular(16.0),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    8.0, 10.0, 8.0, 0.0),
                                            child: Text(
                                              '1. Ajoutez tous les ingrédients dans le récipient et mélangez bien.',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryBtnText,
                                                      ),
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    8.0, 10.0, 8.0, 0.0),
                                            child: Text(
                                              '2. Beurrez une fois la poêle avant de commencer la cuisson des crêpes et placez-la sur feu moyen. Attendez que la poêle chauffe.',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryBtnText,
                                                      ),
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    8.0, 10.0, 8.0, 0.0),
                                            child: Text(
                                              '3. Versez la pâte dans la poêle et dès que la pâte commence à monter, retournez la crêpe.\n',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryBtnText,
                                                      ),
                                            ),
                                          ),
                                        ],
                                      ).animateOnPageLoad(animationsMap[
                                          'columnOnPageLoadAnimation2']!),
                                    ),
                                  ),
                                ),
                              ],
                            ).animateOnPageLoad(
                                animationsMap['columnOnPageLoadAnimation1']!),
                          ),
                        ).animateOnPageLoad(
                            animationsMap['containerOnPageLoadAnimation3']!),
                      ),
                      Container(
                        width: 336.0,
                        height: 157.0,
                        decoration: BoxDecoration(),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 5.0, 0.0, 0.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Align(
                                alignment: AlignmentDirectional(-0.9, 0.0),
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 5.0, 0.0, 0.0),
                                  child: Text(
                                    'Instructions :',
                                    textAlign: TextAlign.start,
                                    style:
                                        FlutterFlowTheme.of(context).bodyMedium,
                                  ),
                                ),
                              ),
                              Opacity(
                                opacity: 0.4,
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 20.0, 0.0, 0.0),
                                  child: Container(
                                    width: 358.0,
                                    height: 186.0,
                                    decoration: BoxDecoration(
                                      color: Color(0xFF588A2B),
                                      boxShadow: [
                                        BoxShadow(
                                          blurRadius: 9.0,
                                          color: Color(0x33000000),
                                          offset: Offset(0.0, 2.0),
                                          spreadRadius: 8.0,
                                        )
                                      ],
                                      borderRadius: BorderRadius.circular(26.0),
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  8.0, 10.0, 8.0, 0.0),
                                          child: Text(
                                            '1. Ajoutez tous les ingrédients dans le récipient et mélangez bien.',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium,
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  8.0, 10.0, 8.0, 0.0),
                                          child: Text(
                                            '2. Beurrez une fois la poêle avant de commencer la cuisson des crêpes et placez-la sur feu moyen. Attendez que la poêle chauffe.',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium,
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  8.0, 10.0, 8.0, 0.0),
                                          child: Text(
                                            '3. Versez la pâte dans la poêle et dès que la pâte commence à monter, retournez la crêpe.',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ).animateOnPageLoad(
                              animationsMap['columnOnPageLoadAnimation3']!),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
