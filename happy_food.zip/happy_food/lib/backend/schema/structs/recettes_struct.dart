// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RecettesStruct extends FFFirebaseStruct {
  RecettesStruct({
    String? name,
    String? category,
    String? niveau,
    List<String>? instructions,
    List<IngredientsStruct>? ingredients,
    String? temps,
    String? four,
    String? image,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _name = name,
        _category = category,
        _niveau = niveau,
        _instructions = instructions,
        _ingredients = ingredients,
        _temps = temps,
        _four = four,
        _image = image,
        super(firestoreUtilData);

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;
  bool hasName() => _name != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  set category(String? val) => _category = val;
  bool hasCategory() => _category != null;

  // "niveau" field.
  String? _niveau;
  String get niveau => _niveau ?? '';
  set niveau(String? val) => _niveau = val;
  bool hasNiveau() => _niveau != null;

  // "instructions" field.
  List<String>? _instructions;
  List<String> get instructions => _instructions ?? const [];
  set instructions(List<String>? val) => _instructions = val;
  void updateInstructions(Function(List<String>) updateFn) =>
      updateFn(_instructions ??= []);
  bool hasInstructions() => _instructions != null;

  // "ingredients" field.
  List<IngredientsStruct>? _ingredients;
  List<IngredientsStruct> get ingredients => _ingredients ?? const [];
  set ingredients(List<IngredientsStruct>? val) => _ingredients = val;
  void updateIngredients(Function(List<IngredientsStruct>) updateFn) =>
      updateFn(_ingredients ??= []);
  bool hasIngredients() => _ingredients != null;

  // "temps" field.
  String? _temps;
  String get temps => _temps ?? '';
  set temps(String? val) => _temps = val;
  bool hasTemps() => _temps != null;

  // "four" field.
  String? _four;
  String get four => _four ?? '';
  set four(String? val) => _four = val;
  bool hasFour() => _four != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  set image(String? val) => _image = val;
  bool hasImage() => _image != null;

  static RecettesStruct fromMap(Map<String, dynamic> data) => RecettesStruct(
        name: data['name'] as String?,
        category: data['category'] as String?,
        niveau: data['niveau'] as String?,
        instructions: getDataList(data['instructions']),
        ingredients: getStructList(
          data['ingredients'],
          IngredientsStruct.fromMap,
        ),
        temps: data['temps'] as String?,
        four: data['four'] as String?,
        image: data['image'] as String?,
      );

  static RecettesStruct? maybeFromMap(dynamic data) =>
      data is Map ? RecettesStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'category': _category,
        'niveau': _niveau,
        'instructions': _instructions,
        'ingredients': _ingredients?.map((e) => e.toMap()).toList(),
        'temps': _temps,
        'four': _four,
        'image': _image,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'category': serializeParam(
          _category,
          ParamType.String,
        ),
        'niveau': serializeParam(
          _niveau,
          ParamType.String,
        ),
        'instructions': serializeParam(
          _instructions,
          ParamType.String,
          true,
        ),
        'ingredients': serializeParam(
          _ingredients,
          ParamType.DataStruct,
          true,
        ),
        'temps': serializeParam(
          _temps,
          ParamType.String,
        ),
        'four': serializeParam(
          _four,
          ParamType.String,
        ),
        'image': serializeParam(
          _image,
          ParamType.String,
        ),
      }.withoutNulls;

  static RecettesStruct fromSerializableMap(Map<String, dynamic> data) =>
      RecettesStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        category: deserializeParam(
          data['category'],
          ParamType.String,
          false,
        ),
        niveau: deserializeParam(
          data['niveau'],
          ParamType.String,
          false,
        ),
        instructions: deserializeParam<String>(
          data['instructions'],
          ParamType.String,
          true,
        ),
        ingredients: deserializeStructParam<IngredientsStruct>(
          data['ingredients'],
          ParamType.DataStruct,
          true,
          structBuilder: IngredientsStruct.fromSerializableMap,
        ),
        temps: deserializeParam(
          data['temps'],
          ParamType.String,
          false,
        ),
        four: deserializeParam(
          data['four'],
          ParamType.String,
          false,
        ),
        image: deserializeParam(
          data['image'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'RecettesStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is RecettesStruct &&
        name == other.name &&
        category == other.category &&
        niveau == other.niveau &&
        listEquality.equals(instructions, other.instructions) &&
        listEquality.equals(ingredients, other.ingredients) &&
        temps == other.temps &&
        four == other.four &&
        image == other.image;
  }

  @override
  int get hashCode => const ListEquality().hash(
      [name, category, niveau, instructions, ingredients, temps, four, image]);
}

RecettesStruct createRecettesStruct({
  String? name,
  String? category,
  String? niveau,
  String? temps,
  String? four,
  String? image,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    RecettesStruct(
      name: name,
      category: category,
      niveau: niveau,
      temps: temps,
      four: four,
      image: image,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

RecettesStruct? updateRecettesStruct(
  RecettesStruct? recettes, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    recettes
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addRecettesStructData(
  Map<String, dynamic> firestoreData,
  RecettesStruct? recettes,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (recettes == null) {
    return;
  }
  if (recettes.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && recettes.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final recettesData = getRecettesFirestoreData(recettes, forFieldValue);
  final nestedData = recettesData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = recettes.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getRecettesFirestoreData(
  RecettesStruct? recettes, [
  bool forFieldValue = false,
]) {
  if (recettes == null) {
    return {};
  }
  final firestoreData = mapToFirestore(recettes.toMap());

  // Add any Firestore field values
  recettes.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getRecettesListFirestoreData(
  List<RecettesStruct>? recettess,
) =>
    recettess?.map((e) => getRecettesFirestoreData(e, true)).toList() ?? [];
