// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class HappyfoodStruct extends FFFirebaseStruct {
  HappyfoodStruct({
    String? ingredients,
    String? recettes,
    String? abricot,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _ingredients = ingredients,
        _recettes = recettes,
        _abricot = abricot,
        super(firestoreUtilData);

  // "Ingredients" field.
  String? _ingredients;
  String get ingredients => _ingredients ?? '';
  set ingredients(String? val) => _ingredients = val;
  bool hasIngredients() => _ingredients != null;

  // "Recettes" field.
  String? _recettes;
  String get recettes => _recettes ?? '';
  set recettes(String? val) => _recettes = val;
  bool hasRecettes() => _recettes != null;

  // "Abricot" field.
  String? _abricot;
  String get abricot => _abricot ?? '';
  set abricot(String? val) => _abricot = val;
  bool hasAbricot() => _abricot != null;

  static HappyfoodStruct fromMap(Map<String, dynamic> data) => HappyfoodStruct(
        ingredients: data['Ingredients'] as String?,
        recettes: data['Recettes'] as String?,
        abricot: data['Abricot'] as String?,
      );

  static HappyfoodStruct? maybeFromMap(dynamic data) => data is Map
      ? HappyfoodStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'Ingredients': _ingredients,
        'Recettes': _recettes,
        'Abricot': _abricot,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Ingredients': serializeParam(
          _ingredients,
          ParamType.String,
        ),
        'Recettes': serializeParam(
          _recettes,
          ParamType.String,
        ),
        'Abricot': serializeParam(
          _abricot,
          ParamType.String,
        ),
      }.withoutNulls;

  static HappyfoodStruct fromSerializableMap(Map<String, dynamic> data) =>
      HappyfoodStruct(
        ingredients: deserializeParam(
          data['Ingredients'],
          ParamType.String,
          false,
        ),
        recettes: deserializeParam(
          data['Recettes'],
          ParamType.String,
          false,
        ),
        abricot: deserializeParam(
          data['Abricot'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'HappyfoodStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is HappyfoodStruct &&
        ingredients == other.ingredients &&
        recettes == other.recettes &&
        abricot == other.abricot;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([ingredients, recettes, abricot]);
}

HappyfoodStruct createHappyfoodStruct({
  String? ingredients,
  String? recettes,
  String? abricot,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    HappyfoodStruct(
      ingredients: ingredients,
      recettes: recettes,
      abricot: abricot,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

HappyfoodStruct? updateHappyfoodStruct(
  HappyfoodStruct? happyfood, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    happyfood
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addHappyfoodStructData(
  Map<String, dynamic> firestoreData,
  HappyfoodStruct? happyfood,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (happyfood == null) {
    return;
  }
  if (happyfood.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && happyfood.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final happyfoodData = getHappyfoodFirestoreData(happyfood, forFieldValue);
  final nestedData = happyfoodData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = happyfood.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getHappyfoodFirestoreData(
  HappyfoodStruct? happyfood, [
  bool forFieldValue = false,
]) {
  if (happyfood == null) {
    return {};
  }
  final firestoreData = mapToFirestore(happyfood.toMap());

  // Add any Firestore field values
  happyfood.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getHappyfoodListFirestoreData(
  List<HappyfoodStruct>? happyfoods,
) =>
    happyfoods?.map((e) => getHappyfoodFirestoreData(e, true)).toList() ?? [];
