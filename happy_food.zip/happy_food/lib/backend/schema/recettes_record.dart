import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RecettesRecord extends FirestoreRecord {
  RecettesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  bool hasImage() => _image != null;

  // "ingredients" field.
  DocumentReference? _ingredients;
  DocumentReference? get ingredients => _ingredients;
  bool hasIngredients() => _ingredients != null;

  // "four" field.
  String? _four;
  String get four => _four ?? '';
  bool hasFour() => _four != null;

  // "temps" field.
  String? _temps;
  String get temps => _temps ?? '';
  bool hasTemps() => _temps != null;

  // "niveau" field.
  String? _niveau;
  String get niveau => _niveau ?? '';
  bool hasNiveau() => _niveau != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "instructions" field.
  List<String>? _instructions;
  List<String> get instructions => _instructions ?? const [];
  bool hasInstructions() => _instructions != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _image = snapshotData['image'] as String?;
    _ingredients = snapshotData['ingredients'] as DocumentReference?;
    _four = snapshotData['four'] as String?;
    _temps = snapshotData['temps'] as String?;
    _niveau = snapshotData['niveau'] as String?;
    _category = snapshotData['category'] as String?;
    _instructions = getDataList(snapshotData['instructions']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Recettes');

  static Stream<RecettesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RecettesRecord.fromSnapshot(s));

  static Future<RecettesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RecettesRecord.fromSnapshot(s));

  static RecettesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RecettesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RecettesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RecettesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RecettesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RecettesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRecettesRecordData({
  String? name,
  String? image,
  DocumentReference? ingredients,
  String? four,
  String? temps,
  String? niveau,
  String? category,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'image': image,
      'ingredients': ingredients,
      'four': four,
      'temps': temps,
      'niveau': niveau,
      'category': category,
    }.withoutNulls,
  );

  return firestoreData;
}

class RecettesRecordDocumentEquality implements Equality<RecettesRecord> {
  const RecettesRecordDocumentEquality();

  @override
  bool equals(RecettesRecord? e1, RecettesRecord? e2) {
    const listEquality = ListEquality();
    return e1?.name == e2?.name &&
        e1?.image == e2?.image &&
        e1?.ingredients == e2?.ingredients &&
        e1?.four == e2?.four &&
        e1?.temps == e2?.temps &&
        e1?.niveau == e2?.niveau &&
        e1?.category == e2?.category &&
        listEquality.equals(e1?.instructions, e2?.instructions);
  }

  @override
  int hash(RecettesRecord? e) => const ListEquality().hash([
        e?.name,
        e?.image,
        e?.ingredients,
        e?.four,
        e?.temps,
        e?.niveau,
        e?.category,
        e?.instructions
      ]);

  @override
  bool isValidKey(Object? o) => o is RecettesRecord;
}
