import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAXFu49JdbuRoHiHdArgCyxJDy9KyXwYOE",
            authDomain: "happyfood-f08e6.firebaseapp.com",
            projectId: "happyfood-f08e6",
            storageBucket: "happyfood-f08e6.appspot.com",
            messagingSenderId: "755319445172",
            appId: "1:755319445172:web:997527c85b8286896929e1",
            measurementId: "G-TW1PC49HN0"));
  } else {
    await Firebase.initializeApp();
  }
}
