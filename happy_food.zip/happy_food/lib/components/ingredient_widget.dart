import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'ingredient_model.dart';
export 'ingredient_model.dart';

class IngredientWidget extends StatefulWidget {
  const IngredientWidget({Key? key}) : super(key: key);

  @override
  _IngredientWidgetState createState() => _IngredientWidgetState();
}

class _IngredientWidgetState extends State<IngredientWidget> {
  late IngredientModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IngredientModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        Align(
          alignment: AlignmentDirectional(-1.0, 0.0),
          child: Container(
            width: 90.0,
            height: 90.0,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
            ),
            child: Image.network(
              'https://picsum.photos/seed/822/600',
              fit: BoxFit.cover,
            ),
          ),
        ),
        Expanded(
          child: Theme(
            data: ThemeData(
              checkboxTheme: CheckboxThemeData(
                visualDensity: VisualDensity.compact,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
              unselectedWidgetColor: FlutterFlowTheme.of(context).secondaryText,
            ),
            child: CheckboxListTile(
              value: _model.checkboxListTileValue ??= false,
              onChanged: (newValue) async {
                setState(() => _model.checkboxListTileValue = newValue!);
              },
              title: Text(
                'Title',
                style: FlutterFlowTheme.of(context).titleLarge,
              ),
              subtitle: Text(
                'Subtitle goes here...',
                style: FlutterFlowTheme.of(context).labelMedium,
              ),
              tileColor: FlutterFlowTheme.of(context).secondaryBackground,
              activeColor: FlutterFlowTheme.of(context).primary,
              checkColor: FlutterFlowTheme.of(context).info,
              dense: false,
              controlAffinity: ListTileControlAffinity.trailing,
            ),
          ),
        ),
      ],
    );
  }
}
